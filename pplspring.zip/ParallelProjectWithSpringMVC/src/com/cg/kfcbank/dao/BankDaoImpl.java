package com.cg.kfcbank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


import org.springframework.stereotype.Repository;

import com.cg.kfcbank.bean.Bank;

@Repository
public class BankDaoImpl implements IBankDao
{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public Bank addCustomer(Bank bank) {
		System.err.println("###################################################################");
		System.err.println(bank);
		entityManager.persist(bank);
		entityManager.flush();
		return bank;
	
	}

	@Override
	public List<Bank> getAllDetails() {
		
	
		TypedQuery<Bank> query = entityManager.createQuery("SELECT b FROM Bank b", Bank.class);
		return query.getResultList();
}
}
